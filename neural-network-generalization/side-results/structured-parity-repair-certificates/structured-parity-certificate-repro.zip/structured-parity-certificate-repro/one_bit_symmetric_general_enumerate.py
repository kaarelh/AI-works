"""Exact complete sign-cone enumeration for a free bit and an even symmetric block."""
import itertools,math,json,sys,bisect
from fractions import Fraction as F
n=int(sys.argv[1]);r=int(sys.argv[2]);risk=F(sys.argv[3]) if len(sys.argv)>3 else F(1,3)
assert n%2==0
D=1<<(n-1);weights=[math.comb(n-1,h) for h in range(n)];threshold=2*(1-2*risk);maxbias=sum(sorted(weights,reverse=True)[:r]);cut=threshold*D-maxbias
pats=[]
for s in range(r+1):
 for roots in itertools.combinations(range(n),s):
  d=sum((-1)**(j+i)*weights[j] for i,j in enumerate(roots))
  for sig in [1,-1]:
   if sig*d>=cut:pats.append((sig*d,roots,sig))
pats.sort();biases=[p[0] for p in pats];rows=[];allcount=0
for d0,roots0,sig0 in pats:
 j=bisect.bisect_left(biases,threshold*D-d0)
 for dplus,roots1,sigplus in pats[j:]:
  sig1=-sigplus;allcount+=1
  if len(roots0)==r and len(roots1)==r and sig0!=sig1:continue
  g0=[sig0*(-1)**bisect.bisect_left(roots0,h) for h in range(n+1)]
  g1=[sig1*(-1)**bisect.bisect_left(roots1,h) for h in range(n+1)]
  rows.append(dict(k=n+1,blocks=[1,n],r=r,R=str((1-F(d0+dplus,2*D))/2),signs=g0+g1,fiber_roots=[roots0,roots1]))
path=f'one_bit_symmetric_exact_feasible_k{n+1}r{r}_risk{str(risk).replace("/","_")}.json';json.dump(dict(n=n,r=r,risk=str(risk),high_bias_fibers=len(pats),all_accurate_pairs=allcount,feasible_pairs=len(rows),cones=rows),open(path,'w'))
print(path,'highbias',len(pats),'accurate',allcount,'feasible',len(rows),flush=True)

"""Independent complete enumeration and rational dual checker. Standard library only.
Usage: python verify_two_free_cubic_certificates.py [--enumeration-only]
       python verify_two_free_cubic_certificates.py --chunk FILE
"""
import bisect,itertools,json,math,sys,time
from fractions import Fraction as F
from pathlib import Path
root=Path(__file__).parent;n=25;k=27;r=3;N=104;T=F(11,3);D=1<<24;INF=10**9
source=json.load(open(root/'two_free_cubic_complete_k27r3.json'));cones=source['cones'];degrees=[(i,j,l) for i in (0,1) for j in (0,1) for l in range(4-i-j)];basis=[[(-1)**(i*x+j*y)*math.comb(h,l) if h>=l else 0 for i,j,l in degrees] for x in (0,1) for y in (0,1) for h in range(26)];weights=[F(math.comb(25,h),1<<27) for x in (0,1) for y in (0,1) for h in range(26)];target=[(-1)**(x+y+h) for x in (0,1) for y in (0,1) for h in range(26)]
def canonical(g):
 a,b,c,d=[g[i*26:(i+1)*26] for i in range(4)];out=[]
 for p in [(a,b,c,d),(a,c,b,d),(d,c,b,a),(d,b,c,a)]:
  out.append(bytes(x for row in p for x in row));out.append(bytes(1-x for row in p for x in row[::-1]))
 return min(out)
if '--chunk' not in sys.argv:
 pats=[];edge=[math.comb(24,j) for j in range(25)];maximum=sum(sorted(edge,reverse=True)[:3])
 for s in range(4):
  for roots in itertools.combinations(range(25),s):
   for sig in (-1,1):
    if s==3 and sig==1:continue
    g=tuple((1+sig*(-1)**sum(j<h for j in roots))//2 for h in range(26));bias=sum(math.comb(25,h)*(-1)**h*(2*g[h]-1) for h in range(26))//2
    assert bias==sig*sum((-1)**(j+i)*edge[j] for i,j in enumerate(roots))
    if s==3:lo,hi=-sum(roots)-3,-sum(roots)
    elif s==2 and sig==1:lo,hi=-sum(roots)-2,INF
    elif s==2:lo,hi=-INF,-sum(roots)-25
    else:lo,hi=-INF,INF
    pats.append((g,bias,lo,hi))
 assert len(pats)==2952
 plus=[];minus=[]
 for i,a in enumerate(pats):
  for j,b in enumerate(pats):
   for sign,dest in [(1,plus),(-1,minus)]:
    bias=sign*(a[1]+b[1])
    if 3*(bias+2*maximum)<4*D:continue
    dest.append((bias,i,j,max(-INF,a[2]+b[2]),min(INF,a[3]+b[3])))
 minus.sort();minus_bias=[z[0] for z in minus];keys=set();accurate=feasible=0
 for bias,i,j,lo,hi in plus:
  start=bisect.bisect_left(minus_bias,F(4*D,3)-bias);accurate+=len(minus)-start
  for bias2,l,m,lo2,hi2 in minus[start:]:
   assert 3*(bias+bias2)>=4*D
   if max(lo,lo2)>=min(hi,hi2):continue
   feasible+=1;keys.add(canonical(pats[i][0]+pats[l][0]+pats[m][0]+pats[j][0]))
 assert (accurate,feasible,len(keys))==(1146660,354584,49149)
 stored={bytes((g+1)//2 for g in q['signs']) for q in cones};assert len(stored)==len(cones)==49149 and stored==keys
 print('PASS: complete feasible-sign enumeration, 354584 positive-leading quadruples /49149 orbits.',flush=True)
 if '--enumeration-only' in sys.argv:sys.exit()
paths=[Path(sys.argv[sys.argv.index('--chunk')+1])] if '--chunk' in sys.argv else [root/f'two_free_cubic_exact_k27r3_{a}_{b}.json' for a,b in [(0,200),(200,12500),(12500,25000),(25000,37500),(37500,49149)]]
seen=set();minimum=None;starttime=time.time()
for path in paths:
 data=json.load(open(path));assert data['complete'];chunkmin=None
 for cert in data['certificates']:
  index=cert['index'];assert index not in seen;seen.add(index);g=cones[index]['signs'];E={u for u in range(N) if g[u]!=target[u]};q=[F(0)]*N;cost=[F(0)]*N;bound=F(0)
  for entry in cert['dual']:
   y=F(entry['value']);assert y>=0;kind,u=entry['constraint']
   if kind=='margin':q[u]-=y*g[u];bound+=y
   elif kind=='baseline':assert u in E;cost[u]+=y;bound+=4*y
   elif kind=='neighbor':
    assert u in E;xy,h=divmod(u,26);x,z=divmod(xy,2);ns=[((2*(1-x)+z)*26+h,1),((2*x+1-z)*26+h,1)]
    if h:ns.append((u-1,h))
    if h<25:ns.append((u+1,25-h))
    ns=[(v,m) for v,m in ns if v not in E];count=sum(m for v,m in ns);assert count>=12
    q[u]+=2*T*y*g[u]
    for v,m in ns:q[v]-=2*T*y*F(m,count)*g[v]
    cost[u]+=y;bound+=y*(4*T-T*T*(1+F(3,5*count)))
   else:raise AssertionError(kind)
  assert all(cost[u]==(weights[u] if u in E else 0) for u in range(N))
  assert all(sum(q[u]*basis[u][j] for u in range(N))==0 for j in range(len(degrees)))
  assert bound==F(cert['lower_bound']);chunkmin=bound if chunkmin is None else min(chunkmin,bound);minimum=bound if minimum is None else min(minimum,bound)
 assert len(data['certificates'])==data['end']-data['start'] and {q['index'] for q in data['certificates']}==set(range(data['start'],data['end']))
 assert chunkmin==F(data['minimum']);print('PASS:',path.name,'minimum',float(chunkmin),'seconds',time.time()-starttime,flush=True)
if '--chunk' not in sys.argv:assert seen==set(range(49149))
print('PASS: all rational dual moments, positivity, objective weights and bounds. Minimum:',minimum,float(minimum),flush=True)

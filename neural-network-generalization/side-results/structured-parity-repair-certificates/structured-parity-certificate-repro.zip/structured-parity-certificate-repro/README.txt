CERTIFIED MARGIN-REPAIR BOUNDS FOR STRUCTURED PARITY PREDICTORS
Dmitry Vaintrob, Kaarel Hanni, OpenAI Codex. 16 October 2026.

This is a self-contained paper and reproducible exact certificate bundle.
The theorem concerns the stated all-radius cusp repair model, with eventual
anchoring to the head signs. It is NOT a general posterior sample-complexity
result. See the paper for the exact structured-sign and degree assumptions.

VERIFICATION (Python 3 standard library only)
Run these commands from this directory:

python verify_one_bit_symmetric_certificates.py
python verify_one_bit_symmetric_certificates.py --risk034
python verify_one_bit_symmetric_general.py one_bit_symmetric_k65r4_risk1_3_universal_exact_certificates.json
python verify_one_bit_symmetric_general.py one_bit_symmetric_k65r4_risk17_50_universal_exact_certificates.json
python verify_two_free_cubic_general.py two_free_cubic_general_exact_k41r3_0_86.json
python verify_two_free_cubic_general.py two_free_cubic_general_exact_k47r3_0_3.json
python verify_two_free_cubic_certificates.py

The final command independently reconstructs all 49,149 sign-cone orbits
on 27 coordinates and verifies every rational certificate in five chunks.
It took about four minutes in the research workspace. For partial checks:
python verify_two_free_cubic_certificates.py --enumeration-only
python verify_two_free_cubic_certificates.py --chunk two_free_cubic_exact_k27r3_0_200.json

All arithmetic used to certify the inequalities is rational. No optimization
package or floating-point LP output is needed by the verification scripts.
The checkers independently verify sign-pattern completeness, symmetry-orbit
coverage, nonnegative dual coefficients, all polynomial moment identities,
objective weights, and the stated exact lower bounds.

EXACT RESULTS
One arbitrary bit, K27 degree3:
  risk <=1/3: 193 orbits, 77247413969/13589544960.
  risk <=17/50: 298 orbits, 1785556483667/380507258880.
One arbitrary bit, K65 degree4:
  risk <=1/3: 132 orbits, 114394263199/7851737088.
  risk <=17/50: 801 orbits, 150190794479/15099494400.
Two arbitrary bits, degree3, risk <=1/3:
  K27: 49149 orbits, 77247413969/13589544960.
  K41: 86 orbits, 563724295547/41271951360.
  K47: 3 orbits, 185493561491/12079595520.
All bounds are uniform for 0<beta<=1/2. Equal parity-block lifts and
arbitrary amplitude representatives are covered under the paper's sign
symmetry assumptions.

OPTIONAL CERTIFICATE DISCOVERY
The certify_*.py and enumeration scripts are included for transparency.
They require NumPy, SciPy, and SymPy. They are not needed for verification.
Re-running discovery can take substantially longer than checking the
certificates. The source-enumeration JSON files are included and independently
reconstructed by the checkers, so no discovery output is trusted without
verification.

SHA256SUMS records the exact packaged files (excluding this manifest itself).

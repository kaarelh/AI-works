"""Complete positive-leading sign cone enumeration for two arbitrary bits and an odd radial block."""
import math,itertools,numpy as np,collections,bisect,time,json,sys
n=int(sys.argv[1]) if len(sys.argv)>1 else 25
D=1<<(n-1);w=[math.comb(n-1,j) for j in range(n)];maxb=sum(sorted(w,reverse=True)[:3]);pats=[];INF=10**9
for s in range(4):
 for roots in itertools.combinations(range(n),s):
  d=sum((-1)**(j+i)*w[j] for i,j in enumerate(roots))
  for sig in [-1,1]:
   if s==3 and sig!=-1:continue
   if s==3:lo,hi=-sum(roots)-3,-sum(roots)
   elif s==2 and sig==1:lo,hi=-sum(roots)-2,INF
   elif s==2 and sig==-1:lo,hi=-INF,-sum(roots)-n
   else:lo,hi=-INF,INF
   pats.append(dict(roots=roots,sig=sig,bias=sig*d,lo=lo,hi=hi))
bias=np.array([q['bias'] for q in pats]);threshold=4*D/3;paircut=threshold-2*maxb;plus=[];minus=[]
for i in range(len(pats)):
 for orientation,out in [(1,plus),(-1,minus)]:
  for j in np.flatnonzero(orientation*(bias[i]+bias)>=paircut):
   a,b=pats[i],pats[j];lo=max(-INF,a['lo']+b['lo']);hi=min(INF,a['hi']+b['hi']);out.append((int(orientation*(bias[i]+bias[j])),i,int(j),lo,hi))
minus.sort();db=[q[0] for q in minus];print('PATTERNS',len(pats),'PAIRS',len(plus),len(minus),flush=True);accurate=0;feasible=0;orbits={};start=time.time()
# Target-preserving symmetries preserving positive cubic leading coefficient:
# swap free bits, flip both free bits, and radial reflection with global negation
# (n odd, cubic odd). The latter changes leading sign twice and preserves it.
def canon(ids):
 g=np.array([[pats[i]['sig']*(-1)**bisect.bisect_left(pats[i]['roots'],h) for h in range(n+1)] for i in ids],dtype=np.int8).reshape(2,2,n+1)
 variants=[]
 for swap in [False,True]:
  a=g.swapaxes(0,1) if swap else g
  for flip in [False,True]:
   b=a[::-1,::-1] if flip else a
   variants += [bytes((b.ravel()+1)//2),bytes((-b[:,:,::-1].ravel()+1)//2)]
 return min(variants)
for count,(d,i,j,lo,hi) in enumerate(plus):
 startj=bisect.bisect_left(db,threshold-d);accurate+=len(minus)-startj
 for e,l,m,low,high in minus[startj:]:
  if max(lo,low)>=min(hi,high):continue
  feasible+=1;ids=(i,l,m,j);key=canon(ids)
  if key not in orbits:orbits[key]=dict(pattern_ids=ids,R=str((1-(d+e)/(4*D))/2))
 if count%10000==0:print('STEP',count,'accurate',accurate,'feasible',feasible,'orbits',len(orbits),'sec',time.time()-start,flush=True)
print('COMPLETE','accurate',accurate,'feasible',feasible,'orbits',len(orbits),'sec',time.time()-start,flush=True)
json.dump(dict(n=n,r=3,positive_leading_patterns=len(pats),accurate_positive_leading=accurate,feasible_positive_leading=feasible,orbits=len(orbits),cones=[dict(signs=[2*x-1 for x in key],**v) for key,v in orbits.items()]),open(f'two_free_cubic_complete_k{n+2}r3.json','w'))

"""Standalone exact checker: Python standard library only; no LP solver.
Usage: python verify_one_bit_symmetric_general.py CERTIFICATE.json.
"""
import itertools,json,math,sys
from fractions import Fraction as F
from pathlib import Path
path=Path(sys.argv[1]);data=json.load(open(path));n=data['n'];r=data['r'];risk=F(data['risk']);bits=data['objective_floor_bits'];k=n+1;N=2*(n+1);T=F(11,3);degrees=[(i,j) for i in (0,1) for j in range(r-i+1)];nc=len(degrees)
assert n%2==0
basis=[[(-1)**(i*x)*math.comb(h,j) if h>=j else 0 for i,j in degrees] for x in (0,1) for h in range(n+1)]
weights=[F(math.comb(n,h),2**k) for x in (0,1) for h in range(n+1)];target=[(-1)**(x+h) for x in (0,1) for h in range(n+1)]
objective_weights=[F((v*(1<<bits)).numerator//(v*(1<<bits)).denominator,1<<bits) for v in weights]
assert all(0<=v<=w for v,w in zip(objective_weights,weights))
def canonical(g):
 a,b=g[:n+1],g[n+1:]
 return min(tuple(g),tuple([-x for x in b+a]),tuple(a[::-1]+b[::-1]),tuple([-x for x in b[::-1]+a[::-1]]))
patterns=[];D=1<<(n-1);edge_weights=[math.comb(n-1,h) for h in range(n)];threshold=2*(1-2*risk);maximum=sum(sorted(edge_weights,reverse=True)[:r]);cut=threshold*D-maximum
for count in range(r+1):
 for roots in itertools.combinations(range(n),count):
  num=sum((-1)**(j+i)*edge_weights[j] for i,j in enumerate(roots))
  for sig in (-1,1):
   if sig*num<cut:continue
   g=[sig*(-1)**sum(edge<h for edge in roots) for h in range(n+1)]
   assert sum(math.comb(n,h)*(-1)**h*g[h] for h in range(n+1))==2*sig*num
   patterns.append((g,sig*num,count))
allaccurate=0;feasible=0;keys=set()
for g0,num0,count0 in patterns:
 for gp,nump,countp in patterns:
  if num0+nump<threshold*D:continue
  g1=[-x for x in gp];allaccurate+=1
  if count0==countp==r and g0[-1]!=g1[-1]:continue
  feasible+=1;keys.add(canonical(g0+g1))
assert allaccurate==data['all_accurate_patterns']
assert feasible==data['exact_feasible_patterns']
assert len(keys)==data['symmetry_orbits']
certs={tuple(q['signs']):q for q in data['certificates']};assert set(certs)==keys
minimum=None
for g,cert in certs.items():
 E=[u for u in range(N) if g[u]!=target[u]];pos={u:j for j,u in enumerate(E)};nv=nc+len(E);moment=[F(0)]*nv;bound=F(0)
 for entry in cert['dual']:
  y=F(entry['value']);assert y>=0;kind,u=entry['constraint'];row=[F(0)]*nv
  if kind=='margin':
   row[:nc]=[-g[u]*v for v in basis[u]];rhs=F(-1)
  elif kind=='baseline':row[nc+pos[u]]=-1;rhs=F(-4)
  elif kind=='neighbor':
   x,h=divmod(u,n+1);ns=[((1-x)*(n+1)+h,1)]
   if h:ns.append((u-1,h))
   if h<n:ns.append((u+1,n-h))
   ns=[(v,m) for v,m in ns if g[v]==target[v]];count=sum(m for v,m in ns);assert count>=12
   row[:nc]=[2*T*(g[u]*basis[u][j]-sum(F(m*g[v]*basis[v][j],count) for v,m in ns)) for j in range(nc)];row[nc+pos[u]]=-1;rhs=-(4*T-T*T*(1+F(3,5*count)))
  else:raise AssertionError(kind)
  moment=[a+y*b for a,b in zip(moment,row)];bound-=y*rhs
 expected=[F(0)]*nc+[-objective_weights[u] for u in E];assert moment==expected
 assert bound==F(cert['lower_bound']);assert bound>F(7,2)
 minimum=bound if minimum is None else min(minimum,bound)
assert minimum==F(data['minimum_lower_bound'])
print('PASS: exact enumeration covers',feasible,'feasible cones in',len(keys),'symmetry orbits.')
print('PASS: all rational dual identities and nonnegativity checks hold.')
print('Uniform lower bound:',minimum,'=',float(minimum),'> 7/2 > (4+2 sqrt(2))/2.')

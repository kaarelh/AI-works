"""Exact dual certificates for the complete two-free-bit cubic family; chunkable."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import json,math,time,sys,numpy as np,sympy as sp
from fractions import Fraction as F
from scipy.optimize import linprog
n=int(sys.argv[1]);r=3;k=n+2;N=4*(n+1);T=F(11,3);degrees=[(i,j,l) for i in (0,1) for j in (0,1) for l in range(r-i-j+1)];nc=len(degrees)
basis=np.array([[(-1)**(i*x+j*y)*math.comb(h,l) if h>=l else 0 for i,j,l in degrees] for x in (0,1) for y in (0,1) for h in range(n+1)],dtype=np.int64)
weights=[F(math.comb(n,h),1<<k) for x in (0,1) for y in (0,1) for h in range(n+1)];target=np.array([(-1)**(x+y+h) for x in (0,1) for y in (0,1) for h in range(n+1)]);neighbors=[]
for x in (0,1):
 for y in (0,1):
  for h in range(n+1):
   u=(2*x+y)*(n+1)+h;ns=[((2*(1-x)+y)*(n+1)+h,1),((2*x+1-y)*(n+1)+h,1)]
   if h:ns.append((u-1,h))
   if h<n:ns.append((u+1,n-h))
   neighbors.append(ns)
data=json.load(open(f'two_free_cubic_complete_k{k}r3.json'));source=data['cones'];start=int(sys.argv[2]) if len(sys.argv)>2 else 0;end=min(len(source),int(sys.argv[3])) if len(sys.argv)>3 else len(source);outpath=f'two_free_cubic_general_exact_k{k}r3_{start}_{end}.json';certs=[];minimum=F(10**20);st=time.time()
for index in range(start,end):
 g=np.array(source[index]['signs']);E=list(np.flatnonzero(g!=target));nw=len(E);nv=nc+nw;A=[];rhs=[];labels=[]
 for u in range(N):A.append([F(-g[u]*int(v)) for v in basis[u]]+[F(0)]*nw);rhs.append(F(-1));labels.append(['margin',u])
 for j,u in enumerate(E):
  row=[F(0)]*nv;row[nc+j]=-1;A.append(row);rhs.append(F(-4));labels.append(['baseline',int(u)])
  ns=[(v,m) for v,m in neighbors[u] if g[v]==target[v]];count=sum(m for v,m in ns)
  if count<12:continue
  grad=[2*T*(g[u]*int(basis[u,l])-sum(F(m*g[v]*int(basis[v,l]),count) for v,m in ns)) for l in range(nc)];row=grad+[F(0)]*nw;row[nc+j]=-1;constant=4*T-T*T*(F(1)+F(3,5*count));A.append(row);rhs.append(-constant);labels.append(['neighbor',int(u)])
 obj=[F(0)]*nc+[F((weights[u]*(1<<30)).numerator//(weights[u]*(1<<30)).denominator,1<<30) for u in E];scale=np.r_[1/np.maximum(1,np.max(abs(basis),axis=0)),np.ones(nw)];lp=linprog(np.array(obj,float)*scale,A_ub=np.array(A,float)*scale,b_ub=np.array(rhs,float),bounds=[(None,None)]*nv,method='highs',options={'dual_feasibility_tolerance':1e-9,'primal_feasibility_tolerance':1e-9});assert lp.success,(index,lp.message)
 support=np.flatnonzero(-lp.ineqlin.marginals>1e-11);mat=sp.Matrix([[sp.Rational(A[j][l].numerator,A[j][l].denominator) for j in support] for l in range(nv)]);vec=sp.Matrix([-sp.Rational(v.numerator,v.denominator) for v in obj]);sol,params=mat.gauss_jordan_solve(vec)
 if params.rows:sol=sol.subs({v:0 for v in params})
 assert all(v>=0 for v in sol),('negative dual',index)
 assert mat*sol==vec
 val=-sum(sp.Rational(rhs[j].numerator,rhs[j].denominator)*v for j,v in zip(support,sol));minimum=min(minimum,F(int(sp.numer(val)),int(sp.denom(val))))
 certs.append(dict(index=index,lower_bound=str(val),dual=[dict(constraint=labels[j],value=str(v)) for j,v in zip(support,sol) if v]))
 if index%50==0 or val<F(7,2):print('CERTIFIED',index,'value',float(val),'minimum',float(minimum),'sec',time.time()-st,flush=True)
 if (index-start)%100==0:json.dump(dict(n=n,r=r,objective_floor_bits=30,start=start,end=end,complete=False,minimum=str(minimum),certificates=certs),open(outpath,'w'))
json.dump(dict(n=n,r=r,objective_floor_bits=30,start=start,end=end,complete=True,minimum=str(minimum),certificates=certs),open(outpath,'w'))
print('COMPLETE',start,end,'minimum',minimum,float(minimum),'sec',time.time()-st,flush=True)

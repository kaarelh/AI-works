"""Exact rational all-relay lower certificates for every accurate one-bit/symmetric degree-3 sign cone.
Completeness is the elementary sign-transition enumeration, with exact leading-coefficient feasibility.
The linear dual coefficients are reconstructed over Q and verified exactly.
"""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import json,math,time,numpy as np,sympy as sp
from fractions import Fraction as F
from scipy.optimize import linprog
from scipy import sparse

n=26;r=3;k=n+1;N=2*(n+1);degs=[(i,j) for i in [0,1] for j in range(r-i+1)];nc=len(degs);T=F(11,3);basis=np.array([[(-1)**(i*x)*math.comb(h,j) if h>=j else 0 for i,j in degs] for x in [0,1] for h in range(n+1)],dtype=np.int64);weights=[F(math.comb(n,h),1<<(n+1)) for x in [0,1] for h in range(n+1)];target=np.array([(-1)**(x+h) for x in [0,1] for h in range(n+1)]);neighbors=[]
for x in [0,1]:
 for h in range(n+1):
  ns=[((1-x)*(n+1)+h,1)]
  if h:ns.append((x*(n+1)+h-1,h))
  if h<n:ns.append((x*(n+1)+h+1,n-h))
  neighbors.append(ns)
source=json.load(open('one_bit_symmetric_exact_feasible_k27r3.json'));orbits={}
for q in source:
 g=np.array(q['signs'],int).reshape(2,n+1);variants=[g,-g[::-1],g[:,::-1],-g[::-1,::-1]];key=min(tuple(v.ravel()) for v in variants);orbits[key]=q
print('ORBIT_COUNT',len(orbits),flush=True);certs=[];st=time.time();minimum=F(10**10)
for index,key in enumerate(sorted(orbits)):
 g=np.array(key);E=list(np.flatnonzero(g!=target));nw=len(E);nv=nc+nw;A=[];rhs=[];labels=[]
 for u in range(N):A.append([F(-g[u]*int(v)) for v in basis[u]]+[F(0)]*nw);rhs.append(F(-1));labels.append(['margin',u])
 for j,u in enumerate(E):
  row=[F(0)]*nv;row[nc+j]=-1;A.append(row);rhs.append(F(-4));labels.append(['baseline',int(u)])
  ns=[(v,m) for v,m in neighbors[u] if g[v]==target[v]];count=sum(m for v,m in ns)
  if count<12:continue
  grad=[2*T*(g[u]*int(basis[u,l])-sum(F(m*g[v]*int(basis[v,l]),count) for v,m in ns)) for l in range(nc)];row=grad+[F(0)]*nw;row[nc+j]=-1;constant=4*T-T*T*(F(1)+F(3,5*count));A.append(row);rhs.append(-constant);labels.append(['neighbor',int(u)])
 obj=[F(0)]*nc+[weights[u] for u in E];lp=linprog(np.array(obj,float),A_ub=np.array(A,float),b_ub=np.array(rhs,float),bounds=[(None,None)]*nv,method='highs',options={'dual_feasibility_tolerance':1e-9,'primal_feasibility_tolerance':1e-9});assert lp.success,lp.message
 support=np.flatnonzero(-lp.ineqlin.marginals>1e-11);mat=sp.Matrix([[sp.Rational(A[j][l].numerator,A[j][l].denominator) for j in support] for l in range(nv)]);vec=sp.Matrix([-sp.Rational(v.numerator,v.denominator) for v in obj]);sol,params=mat.gauss_jordan_solve(vec)
 if params.rows:sol=sol.subs({v:0 for v in params})
 assert all(v>=0 for v in sol),('negative dual',index)
 assert mat*sol==vec
 val=-sum(sp.Rational(rhs[j].numerator,rhs[j].denominator)*v for j,v in zip(support,sol));assert val>F(7,2),('bound below3.5',index,val);minimum=min(minimum,F(int(sp.numer(val)),int(sp.denom(val))))
 certificate=dict(signs=list(map(int,key)),R=str(sum(weights[u] for u in E)),lower_bound=str(val),dual=[dict(constraint=labels[j],value=str(v)) for j,v in zip(support,sol) if v]);certs.append(certificate)
 if index%10==0:print('CERTIFIED',index+1,'minimum',float(minimum),'sec',time.time()-st,flush=True);json.dump(dict(n=n,r=r,all_accurate_patterns=1460,exact_feasible_patterns=762,symmetry_orbits=len(orbits),certificates=certs),open('one_bit_symmetric_k27r3_universal_exact_certificates.json','w'))
json.dump(dict(n=n,r=r,all_accurate_patterns=1460,exact_feasible_patterns=762,symmetry_orbits=len(orbits),minimum_lower_bound=str(minimum),certificates=certs),open('one_bit_symmetric_k27r3_universal_exact_certificates.json','w'),indent=2)
print('COMPLETE',len(certs),'minimum',minimum,float(minimum),'sec',time.time()-st,flush=True)

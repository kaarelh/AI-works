"""Standalone exact checker: Python standard library only; no LP solver.
Run from this directory with python verify_one_bit_symmetric_certificates.py.
"""
import itertools,json,math,sys
from fractions import Fraction as F
from pathlib import Path
risk034="--risk034" in sys.argv
n=26;r=3;k=27;N=54;T=F(11,3);degrees=[(i,j) for i in (0,1) for j in range(r-i+1)];nc=len(degrees)
basis=[[(-1)**(i*x)*math.comb(h,j) if h>=j else 0 for i,j in degrees] for x in (0,1) for h in range(n+1)]
weights=[F(math.comb(n,h),2**k) for x in (0,1) for h in range(n+1)];target=[(-1)**(x+h) for x in (0,1) for h in range(n+1)]
def canonical(g):
 a,b=g[:n+1],g[n+1:]
 return min(tuple(g),tuple([-x for x in b+a]),tuple(a[::-1]+b[::-1]),tuple([-x for x in b[::-1]+a[::-1]]))
patterns=[]
for count in range(r+1):
 for roots in itertools.combinations(range(n),count):
  g=[(-1)**sum(edge<h for edge in roots) for h in range(n+1)];num=sum(math.comb(n,h)*(-1)**h*g[h] for h in range(n+1))
  patterns.extend([(g,num,count),([-x for x in g],-num,count)])
patterns.sort(key=lambda z:z[1]);allaccurate=0;feasible=0;keys=set()
for g0,num0,count0 in patterns:
 for g1,num1,count1 in patterns:
  if (25*(num0-num1)<16*2**n) if risk034 else (3*(num0-num1)<2*2**n):break
  allaccurate+=1
  if count0==count1==r and g0[-1]!=g1[-1]:continue
  feasible+=1;keys.add(canonical(g0+g1))
expected_counts=(5904,2256,1176,298) if risk034 else (5904,1460,762,193)
assert (len(patterns),allaccurate,feasible,len(keys))==expected_counts
path=Path(__file__).with_name('one_bit_symmetric_k27r3_risk034_exact_certificates.json' if risk034 else 'one_bit_symmetric_k27r3_universal_exact_certificates.json');data=json.load(open(path));certs={tuple(q['signs']):q for q in data['certificates']};assert set(certs)==keys
minimum=None
for g,cert in certs.items():
 E=[u for u in range(N) if g[u]!=target[u]];pos={u:j for j,u in enumerate(E)};nv=nc+len(E);moment=[F(0)]*nv;bound=F(0)
 for entry in cert['dual']:
  y=F(entry['value']);assert y>=0;kind,u=entry['constraint'];row=[F(0)]*nv
  if kind=='margin':
   row[:nc]=[-g[u]*v for v in basis[u]];rhs=F(-1)
  elif kind=='baseline':row[nc+pos[u]]=-1;rhs=F(-4)
  elif kind=='neighbor':
   x,h=divmod(u,n+1);ns=[((1-x)*(n+1)+h,1)]
   if h:ns.append((u-1,h))
   if h<n:ns.append((u+1,n-h))
   ns=[(v,m) for v,m in ns if g[v]==target[v]];count=sum(m for v,m in ns);assert count>=12
   row[:nc]=[2*T*(g[u]*basis[u][j]-sum(F(m*g[v]*basis[v][j],count) for v,m in ns)) for j in range(nc)];row[nc+pos[u]]=-1;rhs=-(4*T-T*T*(1+F(3,5*count)))
  else:raise AssertionError(kind)
  moment=[a+y*b for a,b in zip(moment,row)];bound-=y*rhs
 expected=[F(0)]*nc+[-weights[u] for u in E];assert moment==expected
 assert bound==F(cert['lower_bound']);assert bound>(F(9,2) if risk034 else F(11,2))
 minimum=bound if minimum is None else min(minimum,bound)
assert minimum==F(data['minimum_lower_bound'])
print('PASS: exact enumeration covers',feasible,'feasible cones in',len(keys),'symmetry orbits.')
print('PASS: all rational dual identities and nonnegativity checks hold.')
print('Uniform lower bound:',minimum,'=',float(minimum),'> 9/2 > (4+2 sqrt(2))/2.' if risk034 else '> 11/2 > (4+2 sqrt(2))/2.')

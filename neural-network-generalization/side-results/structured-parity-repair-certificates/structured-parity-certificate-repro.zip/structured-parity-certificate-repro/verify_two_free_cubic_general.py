"""Independent complete enumeration and rational dual checker. Standard library only.
Usage: python verify_two_free_cubic_general.py CERTIFICATE.json
       Add --skip-enumeration to check only the rational dual data.
"""
import bisect,itertools,json,math,sys,time
from fractions import Fraction as F
from pathlib import Path
root=Path(__file__).parent;certpath=Path(sys.argv[1]);certificate_data=json.load(open(certpath));n=certificate_data['n'];k=n+2;r=3;N=4*(n+1);T=F(11,3);D=1<<(n-1);INF=10**9
source=json.load(open(root/f'two_free_cubic_complete_k{k}r3.json'));cones=source['cones'];degrees=[(i,j,l) for i in (0,1) for j in (0,1) for l in range(4-i-j)];basis=[[(-1)**(i*x+j*y)*math.comb(h,l) if h>=l else 0 for i,j,l in degrees] for x in (0,1) for y in (0,1) for h in range(n+1)];weights=[F(math.comb(n,h),1<<k) for x in (0,1) for y in (0,1) for h in range(n+1)];target=[(-1)**(x+y+h) for x in (0,1) for y in (0,1) for h in range(n+1)];bits=certificate_data['objective_floor_bits'];weights=[F((w*(1<<bits)).numerator//(w*(1<<bits)).denominator,1<<bits) for w in weights]
def canonical(g):
 a,b,c,d=[g[i*(n+1):(i+1)*(n+1)] for i in range(4)];out=[]
 for p in [(a,b,c,d),(a,c,b,d),(d,c,b,a),(d,b,c,a)]:
  out.append(bytes(x for row in p for x in row));out.append(bytes(1-x for row in p for x in row[::-1]))
 return min(out)
if '--skip-enumeration' not in sys.argv:
 pats=[];edge=[math.comb(n-1,j) for j in range(n)];maximum=sum(sorted(edge,reverse=True)[:3])
 for s in range(4):
  for roots in itertools.combinations(range(n),s):
   for sig in (-1,1):
    if s==3 and sig==1:continue
    g=tuple((1+sig*(-1)**sum(j<h for j in roots))//2 for h in range(n+1));bias=sum(math.comb(n,h)*(-1)**h*(2*g[h]-1) for h in range(n+1))//2
    assert bias==sig*sum((-1)**(j+i)*edge[j] for i,j in enumerate(roots))
    if s==3:lo,hi=-sum(roots)-3,-sum(roots)
    elif s==2 and sig==1:lo,hi=-sum(roots)-2,INF
    elif s==2:lo,hi=-INF,-sum(roots)-n
    else:lo,hi=-INF,INF
    pats.append((g,bias,lo,hi))
 assert len(pats)==source['positive_leading_patterns']
 plus=[];minus=[]
 for sign,dest in [(1,plus),(-1,minus)]:
  inds=[i for i,a in enumerate(pats) if 3*(sign*a[1]+3*maximum)>=4*D]
  for i in inds:
   for j in inds:
    a,b=pats[i],pats[j];bias=sign*(a[1]+b[1])
    if 3*(bias+2*maximum)<4*D:continue
    dest.append((bias,i,j,max(-INF,a[2]+b[2]),min(INF,a[3]+b[3])))
 minus.sort();minus_bias=[z[0] for z in minus];keys=set();accurate=feasible=0
 for bias,i,j,lo,hi in plus:
  start=bisect.bisect_left(minus_bias,F(4*D,3)-bias);accurate+=len(minus)-start
  for bias2,l,m,lo2,hi2 in minus[start:]:
   assert 3*(bias+bias2)>=4*D
   if max(lo,lo2)>=min(hi,hi2):continue
   feasible+=1;keys.add(canonical(pats[i][0]+pats[l][0]+pats[m][0]+pats[j][0]))
 assert (accurate,feasible,len(keys))==(source['accurate_positive_leading'],source['feasible_positive_leading'],source['orbits'])
 stored={bytes((g+1)//2 for g in q['signs']) for q in cones};assert len(stored)==len(cones)==source['orbits'] and stored==keys
 print('PASS: complete feasible-sign enumeration:',feasible,'quadruples,',len(keys),'orbits.',flush=True)
 if '--enumeration-only' in sys.argv:sys.exit()
paths=[certpath]
seen=set();minimum=None;starttime=time.time()
for path in paths:
 data=json.load(open(path));assert data['complete'];chunkmin=None
 for cert in data['certificates']:
  index=cert['index'];assert index not in seen;seen.add(index);g=cones[index]['signs'];E={u for u in range(N) if g[u]!=target[u]};q=[F(0)]*N;cost=[F(0)]*N;bound=F(0)
  for entry in cert['dual']:
   y=F(entry['value']);assert y>=0;kind,u=entry['constraint']
   if kind=='margin':q[u]-=y*g[u];bound+=y
   elif kind=='baseline':assert u in E;cost[u]+=y;bound+=4*y
   elif kind=='neighbor':
    assert u in E;xy,h=divmod(u,n+1);x,z=divmod(xy,2);ns=[((2*(1-x)+z)*(n+1)+h,1),((2*x+1-z)*(n+1)+h,1)]
    if h:ns.append((u-1,h))
    if h<n:ns.append((u+1,n-h))
    ns=[(v,m) for v,m in ns if v not in E];count=sum(m for v,m in ns);assert count>=12
    q[u]+=2*T*y*g[u]
    for v,m in ns:q[v]-=2*T*y*F(m,count)*g[v]
    cost[u]+=y;bound+=y*(4*T-T*T*(1+F(3,5*count)))
   else:raise AssertionError(kind)
  assert all(cost[u]==(weights[u] if u in E else 0) for u in range(N))
  assert all(sum(q[u]*basis[u][j] for u in range(N))==0 for j in range(len(degrees)))
  assert bound==F(cert['lower_bound']);chunkmin=bound if chunkmin is None else min(chunkmin,bound);minimum=bound if minimum is None else min(minimum,bound)
 assert len(data['certificates'])==data['end']-data['start'] and {q['index'] for q in data['certificates']}==set(range(data['start'],data['end']))
 assert chunkmin==F(data['minimum']);print('PASS:',path.name,'minimum',float(chunkmin),'seconds',time.time()-starttime,flush=True)
assert seen==set(range(len(cones)))
print('PASS: all rational dual moments, positivity, objective weights and bounds. Minimum:',minimum,float(minimum),flush=True)

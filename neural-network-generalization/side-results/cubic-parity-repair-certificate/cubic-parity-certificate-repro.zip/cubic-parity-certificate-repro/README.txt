EXACT CUBIC PARITY REPAIR CERTIFICATE

Scope: the all-radius cusp variogram model in the accompanying paper.
Heads are cubic on27 bits and symmetric in26 bits, or belong to the stated
parity-block sign-pattern extension. This is not a general posterior theorem.

Verify using Python3 and its standard library only:
  python verify_one_bit_symmetric_certificates.py
  python verify_one_bit_symmetric_certificates.py --risk034

The first command covers error<=1/3 and checks193 exact rational duals.
The second covers error<=.34 and checks298 exact rational duals.
Both commands independently enumerate all sign patterns and verify coverage.
No numerical optimization output is trusted by the checker.

Optional certificate regeneration (requires NumPy, SciPy, SymPy):
  python certify_one_bit_symmetric_phi_universal.py
  python certify_one_bit_symmetric_phi_risk034.py
Run these in this directory. The supplied feasible-cone lists are inputs;
the independent checker re-enumerates them through the output coverage.

Authors: Dmitry Vaintrob, Kaarel Haenni, OpenAI Codex.
16 October2026.
